# Convert Seurat Obj (rds) to Scanpy obj (adata)

## Usage:
```
conda enve create -f env.yaml
conda activate seuratToAdata
seuratToAdata file.rds -o file
```